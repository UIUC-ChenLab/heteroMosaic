#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "XRT::xilinxopencl" for configuration "Release"
set_property(TARGET XRT::xilinxopencl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xilinxopencl PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "XRT::xrt++;XRT::xrt_coreutil"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxilinxopencl.so.2.20.0"
  IMPORTED_SONAME_RELEASE "libxilinxopencl.so.2"
  )

list(APPEND _cmake_import_check_targets XRT::xilinxopencl )
list(APPEND _cmake_import_check_files_for_XRT::xilinxopencl "${_IMPORT_PREFIX}/xrt/lib/libxilinxopencl.so.2.20.0" )

# Import target "XRT::xilinxopencl_static" for configuration "Release"
set_property(TARGET XRT::xilinxopencl_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xilinxopencl_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxilinxopencl_static.a"
  )

list(APPEND _cmake_import_check_targets XRT::xilinxopencl_static )
list(APPEND _cmake_import_check_files_for_XRT::xilinxopencl_static "${_IMPORT_PREFIX}/xrt/lib/libxilinxopencl_static.a" )

# Import target "XRT::xrt++" for configuration "Release"
set_property(TARGET XRT::xrt++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt++ PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "XRT::xrt_coreutil;Boost::system"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt++.so.2.20.0"
  IMPORTED_SONAME_RELEASE "libxrt++.so.2"
  )

list(APPEND _cmake_import_check_targets XRT::xrt++ )
list(APPEND _cmake_import_check_files_for_XRT::xrt++ "${_IMPORT_PREFIX}/xrt/lib/libxrt++.so.2.20.0" )

# Import target "XRT::xrt++_static" for configuration "Release"
set_property(TARGET XRT::xrt++_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt++_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt++_static.a"
  )

list(APPEND _cmake_import_check_targets XRT::xrt++_static )
list(APPEND _cmake_import_check_files_for_XRT::xrt++_static "${_IMPORT_PREFIX}/xrt/lib/libxrt++_static.a" )

# Import target "XRT::xrt_coreutil" for configuration "Release"
set_property(TARGET XRT::xrt_coreutil APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt_coreutil PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt_coreutil.so.2.20.0"
  IMPORTED_SONAME_RELEASE "libxrt_coreutil.so.2"
  )

list(APPEND _cmake_import_check_targets XRT::xrt_coreutil )
list(APPEND _cmake_import_check_files_for_XRT::xrt_coreutil "${_IMPORT_PREFIX}/xrt/lib/libxrt_coreutil.so.2.20.0" )

# Import target "XRT::xrt_coreutil_static" for configuration "Release"
set_property(TARGET XRT::xrt_coreutil_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt_coreutil_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt_coreutil_static.a"
  )

list(APPEND _cmake_import_check_targets XRT::xrt_coreutil_static )
list(APPEND _cmake_import_check_files_for_XRT::xrt_coreutil_static "${_IMPORT_PREFIX}/xrt/lib/libxrt_coreutil_static.a" )

# Import target "XRT::xrt_core" for configuration "Release"
set_property(TARGET XRT::xrt_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt_core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "XRT::xrt_coreutil"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt_core.so.2.20.0"
  IMPORTED_SONAME_RELEASE "libxrt_core.so.2"
  )

list(APPEND _cmake_import_check_targets XRT::xrt_core )
list(APPEND _cmake_import_check_files_for_XRT::xrt_core "${_IMPORT_PREFIX}/xrt/lib/libxrt_core.so.2.20.0" )

# Import target "XRT::xrt_core_static" for configuration "Release"
set_property(TARGET XRT::xrt_core_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::xrt_core_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/lib/libxrt_core_static.a"
  )

list(APPEND _cmake_import_check_targets XRT::xrt_core_static )
list(APPEND _cmake_import_check_files_for_XRT::xrt_core_static "${_IMPORT_PREFIX}/xrt/lib/libxrt_core_static.a" )

# Import target "XRT::pyxrt" for configuration "Release"
set_property(TARGET XRT::pyxrt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(XRT::pyxrt PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/xrt/python/pyxrt.cpython-312-x86_64-linux-gnu.so"
  IMPORTED_NO_SONAME_RELEASE "TRUE"
  )

list(APPEND _cmake_import_check_targets XRT::pyxrt )
list(APPEND _cmake_import_check_files_for_XRT::pyxrt "${_IMPORT_PREFIX}/xrt/python/pyxrt.cpython-312-x86_64-linux-gnu.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
